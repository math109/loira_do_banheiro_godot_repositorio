# Loira do Banheiro — projeto inicial (Godot 4.3+)

## Como abrir
1. Baixe o Godot 4.3 ou mais novo (godotengine.org).
2. No Project Manager: **Import** → selecione o `project.godot` desta pasta → **Import & Edit**.
3. Aperte **F5** para jogar.

## Controles
- **WASD / setas**: andar
- **Shift**: correr
- **E**: trocar de época (1986 ↔ 2026). Só funciona na sala e no banheiro.

## Mapa
Parada → (portão) → Campus → (porta do Bloco D) → Corredor → porta **D-12** (Sala) ou porta **WC** (Banheiro).

## Como está organizado
- `assets/fundos/` — um PNG 960×640 por cenário, sem o jogador e sem a escuridão.
- `assets/sprites/jogador.png` — o protagonista (32×48).
- `scripts/game.gd` — autoload "Game": época atual, ponto de entrada entre cenas, fade e flash "1986/2026".
- `scripts/room.gd` — cada ambiente: fundo, colisões, escuridão (CanvasModulate), lanterna e luzes (PointLight2D).
- `scripts/porta.gd` — Area2D que leva para outra cena.
- `scripts/player.gd` — movimento top-down em 8 direções.

## Ajustando
- **Colisões**: selecione o nó raiz da cena → Inspector → *Colisões* (são `Rect2` em pixels, as mesmas coordenadas do canvas). Para vê-las enquanto joga, ative **Debug → Visible Collision Shapes**.
- **Escuridão**: `escuridao_presente` / `escuridao_passado` (branco = sem escuridão).
- **Luzes fixas**: `luzes` (x, y, raio).
- **Coisas que só existem numa época**: coloque o nó no grupo `so_passado` ou `so_presente`.

## Próximos passos sugeridos
- Spritesheet do jogador com 4 direções × 3 quadros e trocar o `Sprite2D` por `AnimatedSprite2D`.
- Separar móveis altos (frente das cabines, carteiras) em sprites próprios com **Y Sort**, para o jogador passar por trás deles.
- Interações (tecla de ação + Area2D) e diálogos.
