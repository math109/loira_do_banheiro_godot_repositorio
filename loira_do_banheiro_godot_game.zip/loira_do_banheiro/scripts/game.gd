extends Node
## Autoload "Game": guarda o estado entre as cenas (época atual e ponto de
## entrada) e faz as transições com fade e o flash da troca de época.

var era: String = "presente"  # "presente" (2026) ou "passado" (1986)
var spawn_pos: Variant = null  # Vector2 onde o jogador aparece na próxima cena
var mudando := false

var _camada: CanvasLayer
var _fade: ColorRect
var _rotulo: Label


func _ready() -> void:
	_criar_acoes()
	_camada = CanvasLayer.new()
	_camada.layer = 100
	add_child(_camada)

	_fade = ColorRect.new()
	_fade.color = Color(0, 0, 0, 0)
	_fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_fade.set_anchors_preset(Control.PRESET_FULL_RECT)
	_camada.add_child(_fade)

	_rotulo = Label.new()
	_rotulo.set_anchors_preset(Control.PRESET_FULL_RECT)
	_rotulo.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_rotulo.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_rotulo.add_theme_font_size_override("font_size", 48)
	var fonte := load("res://assets/fontes/silkscreen.woff2") as Font
	if fonte:
		_rotulo.add_theme_font_override("font", fonte)
	_rotulo.modulate.a = 0.0
	_camada.add_child(_rotulo)


## Teclas: WASD ou setas para andar, Shift para correr, E para trocar de época.
func _criar_acoes() -> void:
	_acao("mover_cima", [KEY_W, KEY_UP])
	_acao("mover_baixo", [KEY_S, KEY_DOWN])
	_acao("mover_esquerda", [KEY_A, KEY_LEFT])
	_acao("mover_direita", [KEY_D, KEY_RIGHT])
	_acao("correr", [KEY_SHIFT])
	_acao("trocar_era", [KEY_E])


func _acao(nome: String, teclas: Array) -> void:
	if not InputMap.has_action(nome):
		InputMap.add_action(nome)
	for t in teclas:
		var ev := InputEventKey.new()
		ev.physical_keycode = t
		InputMap.action_add_event(nome, ev)


## Troca de cena com fade preto. `posicao` é onde os pés do jogador aparecem.
func ir_para(cena: String, posicao: Vector2) -> void:
	if mudando:
		return
	mudando = true
	spawn_pos = posicao
	_fade.color = Color(0, 0, 0, 0)
	var tw := create_tween()
	tw.tween_property(_fade, "color:a", 1.0, 0.35)
	await tw.finished
	get_tree().change_scene_to_file(cena)
	await get_tree().process_frame
	await get_tree().process_frame
	var tw2 := create_tween()
	tw2.tween_property(_fade, "color:a", 0.0, 0.35)
	await tw2.finished
	mudando = false


## Flash branco + "1986"/"2026" na tela quando a época muda.
func flash_era() -> void:
	_rotulo.text = "1986" if era == "passado" else "2026"
	_fade.color = Color(1, 1, 1, 0.9)
	_rotulo.modulate.a = 1.0
	var tw := create_tween().set_parallel(true)
	tw.tween_property(_fade, "color:a", 0.0, 0.6)
	tw.tween_property(_rotulo, "modulate:a", 0.0, 1.4)
