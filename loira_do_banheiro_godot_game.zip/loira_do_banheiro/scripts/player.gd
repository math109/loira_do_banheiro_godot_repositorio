extends CharacterBody2D
## Jogador: movimento top-down em 8 direções.
## A origem do nó fica nos PÉS do personagem (o sprite fica acima dela).

@export var velocidade := 110.0
@export var mult_corrida := 1.7

@onready var sprite: Sprite2D = $Sprite2D
var _passo := 0.0


func _ready() -> void:
	add_to_group("jogador")


func _physics_process(delta: float) -> void:
	if Game.mudando:
		velocity = Vector2.ZERO
		return
	var dir := Input.get_vector("mover_esquerda", "mover_direita", "mover_cima", "mover_baixo")
	var correndo := Input.is_action_pressed("correr")
	velocity = dir * velocidade * (mult_corrida if correndo else 1.0)
	move_and_slide()

	# Balanço simples ao andar, até existir uma spritesheet com animação de caminhada.
	if dir != Vector2.ZERO:
		_passo += delta * (14.0 if correndo else 10.0)
		sprite.position.y = -24.0 - absf(sin(_passo)) * 2.0
		if dir.x != 0.0:
			sprite.flip_h = dir.x < 0.0
	else:
		_passo = 0.0
		sprite.position.y = -24.0
