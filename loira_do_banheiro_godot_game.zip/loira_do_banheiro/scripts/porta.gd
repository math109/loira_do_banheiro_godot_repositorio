@tool
extends Area2D
## Porta/passagem: quando o jogador encosta, vai para outra cena.

@export_file("*.tscn") var destino: String
@export var posicao_destino := Vector2.ZERO  ## onde os pés do jogador aparecem na outra cena
@export var tamanho := Vector2(64, 12)


func _ready() -> void:
	if Engine.is_editor_hint():
		return
	var forma := CollisionShape2D.new()
	var ret := RectangleShape2D.new()
	ret.size = tamanho
	forma.shape = ret
	add_child(forma)
	body_entered.connect(_ao_entrar)


func _ao_entrar(corpo: Node2D) -> void:
	if corpo.is_in_group("jogador") and destino != "":
		Game.ir_para(destino, posicao_destino)
