@tool
extends Node2D
## Um ambiente do jogo: fundo (presente e, se houver, passado), colisões,
## escuridão com lanterna e luzes fixas.
## As coordenadas são as mesmas dos cenários do canvas (960x640).
## No editor, o fundo aparece e as colisões são desenhadas em vermelho.

@export_group("Editor")
@export_enum("presente", "passado") var previa_editor := "presente"  ## qual época ver no editor
@export var mostrar_colisoes := true
@export_group("")

@export var fundo_presente: Texture2D
@export var fundo_passado: Texture2D  ## deixe vazio se o lugar não tem versão 1986
@export var escuridao_presente := Color.WHITE  ## branco = sem escuridão
@export var escuridao_passado := Color.WHITE
@export var spawn_padrao := Vector2(480, 400)

@export_group("Colisões")
@export var colisoes: Array[Rect2] = []  ## valem nas duas épocas
@export var colisoes_presente: Array[Rect2] = []
@export var colisoes_passado: Array[Rect2] = []

@export_group("Grade de móveis")  ## carteiras/cadeiras em fileiras
@export var grade_origem := Vector2.ZERO
@export var grade_passo := Vector2.ZERO
@export var grade_qtd := Vector2i.ZERO
@export var grade_tamanho := Vector2.ZERO

@export_group("Luzes")
@export var luzes: Array[Vector3] = []  ## x, y, raio — só acendem quando está escuro
@export var raio_lanterna := 96.0

@onready var fundo: Sprite2D = $Fundo
@onready var jogador: CharacterBody2D = $Jogador

var _modulo: CanvasModulate
var _lanterna: PointLight2D
var _luzes: Array[PointLight2D] = []
var _corpo_presente: StaticBody2D
var _corpo_passado: StaticBody2D


var _debug: Node2D


func _ready() -> void:
	if Engine.is_editor_hint():
		_debug = Node2D.new()
		_debug.z_index = 50
		add_child(_debug, false, Node.INTERNAL_MODE_BACK)
		_debug.draw.connect(_desenhar_debug)
		return
	var fixos: Array[Rect2] = []
	fixos.append_array(colisoes)
	if grade_qtd.x > 0 and grade_qtd.y > 0:
		for j in grade_qtd.y:
			for i in grade_qtd.x:
				var pos := grade_origem + Vector2(i * grade_passo.x, j * grade_passo.y)
				fixos.append(Rect2(pos, grade_tamanho))
	_criar_corpo(fixos)
	_corpo_presente = _criar_corpo(colisoes_presente)
	_corpo_passado = _criar_corpo(colisoes_passado)

	_modulo = CanvasModulate.new()
	add_child(_modulo)
	_lanterna = _criar_luz(jogador, raio_lanterna, Color(1.0, 0.92, 0.75), 1.0)
	_lanterna.position = Vector2(0, -20)
	for l in luzes:
		var ponto := Node2D.new()
		ponto.position = Vector2(l.x, l.y)
		add_child(ponto)
		_luzes.append(_criar_luz(ponto, l.z, Color(0.8, 0.9, 1.0), 0.8))

	if Game.spawn_pos != null:
		jogador.position = Game.spawn_pos
		Game.spawn_pos = null
	else:
		jogador.position = spawn_padrao
	_aplicar_era()


func _process(_delta: float) -> void:
	# Só no editor: mostra o fundo da época escolhida e redesenha as colisões.
	if not Engine.is_editor_hint():
		return
	var f := get_node_or_null("Fundo") as Sprite2D
	if f:
		var tex := fundo_passado if (previa_editor == "passado" and fundo_passado != null) else fundo_presente
		if f.texture != tex:
			f.texture = tex
	if _debug:
		_debug.queue_redraw()


func _desenhar_debug() -> void:
	if not mostrar_colisoes:
		return
	var vermelho := Color(1, 0.15, 0.15, 0.35)
	var borda := Color(1, 0.2, 0.2, 0.9)
	var todas: Array[Rect2] = []
	todas.append_array(colisoes)
	todas.append_array(colisoes_passado if previa_editor == "passado" else colisoes_presente)
	if grade_qtd.x > 0 and grade_qtd.y > 0:
		for j in grade_qtd.y:
			for i in grade_qtd.x:
				todas.append(Rect2(grade_origem + Vector2(i * grade_passo.x, j * grade_passo.y), grade_tamanho))
	for r in todas:
		_debug.draw_rect(r, vermelho, true)
		_debug.draw_rect(r, borda, false, 1.0)
	# portas em verde
	for filho in get_children():
		if filho is Area2D and "tamanho" in filho:
			var t: Vector2 = filho.tamanho
			var rp := Rect2(filho.position - t / 2.0, t)
			_debug.draw_rect(rp, Color(0.2, 1, 0.4, 0.4), true)
			_debug.draw_rect(rp, Color(0.2, 1, 0.4, 1), false, 1.0)
	# luzes em amarelo
	for l in luzes:
		_debug.draw_arc(Vector2(l.x, l.y), l.z, 0, TAU, 48, Color(1, 0.9, 0.3, 0.6), 1.0)


func _unhandled_input(evento: InputEvent) -> void:
	if Engine.is_editor_hint():
		return
	if evento.is_action_pressed("trocar_era") and fundo_passado != null and not Game.mudando:
		Game.era = "passado" if Game.era == "presente" else "presente"
		_aplicar_era()
		Game.flash_era()


func _aplicar_era() -> void:
	var passado := Game.era == "passado" and fundo_passado != null
	fundo.texture = fundo_passado if passado else fundo_presente
	var cor := escuridao_passado if passado else escuridao_presente
	_modulo.color = cor
	var escuro := cor != Color.WHITE
	_lanterna.enabled = escuro
	for l in _luzes:
		l.enabled = escuro
	_corpo_presente.collision_layer = 0 if passado else 1
	_corpo_passado.collision_layer = 1 if passado else 0
	# Nós que você adicionar nos grupos "so_passado"/"so_presente" aparecem só na época certa.
	get_tree().call_group("so_passado", "set_visible", passado)
	get_tree().call_group("so_presente", "set_visible", not passado)


func _criar_corpo(rects: Array[Rect2]) -> StaticBody2D:
	var corpo := StaticBody2D.new()
	add_child(corpo)
	for r in rects:
		var forma := CollisionShape2D.new()
		var ret := RectangleShape2D.new()
		ret.size = r.size
		forma.shape = ret
		forma.position = r.position + r.size / 2.0
		corpo.add_child(forma)
	return corpo


func _criar_luz(alvo: Node2D, raio: float, cor: Color, energia: float) -> PointLight2D:
	var grad := Gradient.new()
	grad.set_color(0, Color(1, 1, 1, 1))
	grad.set_color(1, Color(1, 1, 1, 0))
	var tex := GradientTexture2D.new()
	tex.gradient = grad
	tex.fill = GradientTexture2D.FILL_RADIAL
	tex.fill_from = Vector2(0.5, 0.5)
	tex.fill_to = Vector2(1.0, 0.5)
	tex.width = int(raio * 2.0)
	tex.height = int(raio * 2.0)
	var luz := PointLight2D.new()
	luz.texture = tex
	luz.color = cor
	luz.energy = energia
	alvo.add_child(luz)
	return luz
